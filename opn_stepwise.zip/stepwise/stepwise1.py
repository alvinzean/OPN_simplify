from myutils import calculate_residuals, f_test_critical_value, calculate_f_statistic

def stepwise_regression(X, y, significance_level=0.05):
    included = []  
    excluded = list(range(X.shape[1]))  
    while True:
        changed = False
        
        for i in excluded:
            variables_to_test = included + [i]
            residuals = calculate_residuals(X, y, variables_to_test)
            f_statistic = calculate_f_statistic(residuals, included, excluded, X)
            df_between = 1
            df_within = X.shape[0] - len(variables_to_test) - 1
            critical_value = f_test_critical_value(significance_level, df_between, df_within)
            if f_statistic > critical_value:
                included.append(i)
                excluded.remove(i)
                changed = True
        
        if len(included) > 0:
            for i in included:
                variables_to_test = included.copy()
                variables_to_test.remove(i)
                residuals = calculate_residuals(X, y, variables_to_test)
                f_statistic = calculate_f_statistic(residuals, variables_to_test, [i], X)
                df_between = 1
                df_within = X.shape[0] - len(variables_to_test) - 1
                critical_value = f_test_critical_value(significance_level, df_between, df_within)
                if f_statistic < critical_value:
                    excluded.append(i)
                    included.remove(i)
                    changed = True
        if not changed:
            break
    return included