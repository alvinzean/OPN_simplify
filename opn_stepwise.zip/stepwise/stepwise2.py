import numpy as np
import pandas as pd
def calculate_partial_rss(X, y, feature):
    X_feature = X[feature].values.reshape(-1, 1)
    beta = np.linalg.inv(X_feature.T @ X_feature) @ X_feature.T @ y.values.reshape(-1, 1)
    y_pred = X_feature @ beta
    rss = np.sum((y.values.reshape(-1, 1) - y_pred) ** 2)
    return rss

def calculate_partial_tss(y):
    tss = np.sum((y.values.reshape(-1, 1) - np.mean(y)) ** 2)
    return tss

def calculate_contribution(X, y, feature):
    partial_rss = calculate_partial_rss(X, y, feature)
    partial_tss = calculate_partial_tss(y)
    contribution = partial_rss / partial_tss
    return contribution

def f_cdf(F, d1, d2):
    x = d2 / (d2 + d1 * F)
    I = 1 - ((d2 - 2) % 2) * (np.exp(d1 * np.log(1 + 1 / d2)) * np.power(x, d1) *
                              np.power(1 - x, (d2 - 2) / 2) / (d1 * d2 * np.pi * np.sqrt(d2)))
    return I

def perform_f_test(X, y, included_features, excluded_feature, significance_level):
    X_included = X[included_features].values
    X_excluded = X[excluded_feature].values.reshape(-1, 1)
    
   
    beta_included = np.linalg.inv(X_included.T @ X_included) @ X_included.T @ y.values.reshape(-1, 1)
    y_pred_included = X_included @ beta_included
    # beta_included=np.linalg.lstsq(X_included,y,rcond=None)[0]
    # y_pred_included=X_included.dot(beta_included)
    
    beta_excluded = np.linalg.inv(X_excluded.T @ X_excluded) @ X_excluded.T @ y.values.reshape(-1, 1)
    y_pred_excluded = X_excluded @ beta_excluded
    # beta_excluded=np.linalg.lstsq(X_excluded,y,rcond=None)[0]
    # y_pred_excluded=X_included.dot(beta_excluded)
    
    SSE_included = np.sum((y.values.reshape(-1, 1) - y_pred_included) ** 2)
    SSR_excluded = np.sum((y.values.reshape(-1, 1) - y_pred_excluded) ** 2)
    
    
    if SSE_included == 0:
        return False
    
    
    p = X_included.shape[1]  
    n = len(y)
    denominator = SSE_included / (n - p - 1)
    if denominator == 0:
        return False  
    F = ((SSR_excluded - SSE_included) / p) / (SSE_included / (n - p - 1))
    p_value = 1 - f_cdf(F, p, n-p-1)
    
    if p_value < significance_level:
        return True
    else:
        return False
def stepwise_regression(X, y, significance_level=0.05):
    included_features = []
    excluded_features = list(X.columns)
    
    while True:
        contributions = []

       
        for feature in included_features:
            contribution = calculate_contribution(X, y, feature)
            contributions.append((feature, contribution))

        
        for feature in excluded_features:
            contribution = calculate_contribution(X, y, feature)
            contributions.append((feature, contribution))

        contributions.sort(key=lambda x: x[1])
        best_feature, best_contribution = contributions[0]

        
        if perform_f_test(X, y, included_features, best_feature, significance_level):
            included_features.append(best_feature)
            excluded_features.remove(best_feature)
        else:
            break

    results = pd.DataFrame(data={'Feature': included_features})
    return results