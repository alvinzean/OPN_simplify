from myutils.opn import OPN
from myutils.data_util import combine_columns
import random
import numpy as np
import pandas as pd
import time


def calculate_residuals(X, y, variables):
    X_subset=X.iloc[:,variables]
    new1_colname='1'
    tuple_list = [(0, -1)] * len(df) 
    X_subset.insert(loc=0, column=new1_colname, value=tuple_list)
    X_subset=X_subset.to_numpy()
    y=y.to_numpy()
    XT=OPN.mat_t(X_subset)
    XTX=OPN.mat_multi(XT,X_subset)
    XTX_1=OPN.gauss_inv(XTX)
    XTY=OPN.mat_multi(XT,y)
    w=OPN.mat_multi(XTX_1,XTY)
    y_pred=pd.DataFrame(OPN.mat_multi(X_subset,w))
    y=pd.DataFrame(y)
    y_pred[['Column1', 'Column2']] = y_pred.iloc[:,-1].apply(lambda x: pd.Series(x))
    y_true=pd.read_csv('data/energy_efficiency_data.csv')['Heating_Load']
    residuals = y_true - y_pred.iloc[:,1]
    st=y_pred.iloc[:,1]-np.mean(y_true)
    return residuals,st

def stepwise_regression(X, y):
    n, p = X.shape
    # selected_features = list(range(p))  
    selected_features=list(random.sample(range(p), p))
    best_r2 = 0
    best_features = None
    while True:
        best_r2 = 0
        best_features = None
        for i in selected_features:
            
            new_features = selected_features.copy()
            new_features.remove(i)
            r,st= calculate_residuals(X,y,new_features)
            ssr=np.sum(r**2)
            sst=np.sum(st**2)
            r2=1-(ssr/sst)
        
            if r2 > best_r2:
                best_r2 = r2
                print('houbest',best_r2)
                best_features = new_features
                print('hbf',len(best_features))
    
        if best_r2>=0.91:
            print('hou',best_r2)
            break
        selected_features = best_features
    while True:
        best_r2 = 0
        best_features = None
        for i in range(p):
            if i not in selected_features:
                
                new_features = selected_features.copy()
                new_features.append(i)
                r,st= calculate_residuals(X,y,new_features)
                ssr=np.sum(r**2)
                sst=np.sum(st**2)
                r2=1-(ssr/sst)
                
                if r2 > best_r2:
                    best_r2 = r2
                    print('qianbest',best_r2)
                    best_features = new_features
                    print('qbf',len(best_features))
        if best_r2 - r2<=0.007:
            print('qian',best_r2)
            break
        selected_features = best_features
    return selected_features

start_time=time.time()
df=pd.read_csv('data/energy_efficiency_data.csv')
X=df.iloc[:,:-2]
data1=X.applymap(lambda x:(x,0))
X=combine_columns(X)
X=pd.concat([X,data1],axis=1)
df['Heating_Load']=df['Heating_Load'].apply(lambda x: (x,0))
data=pd.concat([X,df['Heating_Load']],axis=1)
y = data.iloc[:,-1:]
var=stepwise_regression(X,y)
end_time=time.time()
duration=end_time-start_time
print('time:', duration)
print('Feature:', var)