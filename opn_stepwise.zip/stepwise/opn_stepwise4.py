from myutils.opn import OPN
from myutils.data_util import combine_columns
import random
import numpy as np
import pandas as pd
import time


def calculate_residuals(X, y, variables):
    X_subset=X.iloc[:,variables]
    new1_colname='1'
    tuple_list = [(0, -1)] * len(df) 
    X_subset.insert(loc=0, column=new1_colname, value=tuple_list)
    X_subset=X_subset.to_numpy()
    y=y.to_numpy()
    XT=OPN.mat_t(X_subset)
    XTX=OPN.mat_multi(XT,X_subset)
    XTX_1=OPN.gauss_inv(XTX)
    XTY=OPN.mat_multi(XT,y)
    w=OPN.mat_multi(XTX_1,XTY)
    y_pred=pd.DataFrame(OPN.mat_multi(X_subset,w))
    y=pd.DataFrame(y)
    y_pred[['Column1', 'Column2']] = y_pred.iloc[:,-1].apply(lambda x: pd.Series(x))
    y_true=pd.read_csv('data/Folds5x2_pp.csv')['PE']
    residuals = y_true - y_pred.iloc[:,1]
    return residuals
def calculate_aic(X, y, r):
    n, p = X.shape
    ssr = np.sum(r ** 2)
    print(ssr)
    AIC = 2 * p + n * np.log(ssr/n)
    print('aic:',AIC)
    return AIC
def stepwise_regression(X, y, threshold=0.01):
    p = X.shape[1] - 1  
    selected_features = list(random.sample(range(p), p))  
    
    best_aic = np.inf
    best_features = selected_features
    for i in range(p):
        
        for j in selected_features[:]:
            new_features = selected_features.copy()
            new_features.remove(j)
            # beta = np.linalg.lstsq(X[:, new_features], y, rcond=None)[0]
            r=calculate_residuals(X,y,new_features)
            # print('r',r)
            new_aic = calculate_aic(X.iloc[:,new_features], y, r)
            # print(new_aic)
            if new_aic < best_aic:
                best_aic = new_aic
                best_features = new_features
        
        for j in range(p):
            if j not in selected_features:
                new_features = selected_features.copy()
                new_features.append(j)
                # beta = np.linalg.lstsq(X[:, new_features], y, rcond=None)[0]
                r=calculate_residuals(X,y,new_features)
                
                new_aic = calculate_aic(X.iloc[:,new_features], y, r)
                # print(new_aic)
                if new_aic < best_aic:
                    best_aic = new_aic
                    best_features = new_features
    return best_features

start_time=time.time()
df = pd.read_csv('data/Folds5x2_pp.csv')
X = df.iloc[:,:-1]
X = combine_columns(X)
df['PE']=df['PE'].apply(lambda x: (x,0))
data=pd.concat([X,df['PE']],axis=1)
y = data.iloc[:,-1:]
selected_features = stepwise_regression(X, y)
end_time=time.time()
duration=end_time-start_time
print('time:', duration)
print("Selected features:", selected_features)