import numpy as np
import pandas as pd

def calculate_adjusted_r2(X, y, included_features):
    n = len(y)
    p = len(included_features)
    X_included = X[included_features].values

    
    beta = np.linalg.inv(X_included.T @ X_included) @ X_included.T @ y.values.reshape(-1, 1)
    y_pred = X_included @ beta
    
    SSE = np.sum((y.values.reshape(-1, 1) - y_pred) ** 2)
    SST = np.sum((y.values.reshape(-1, 1) - np.mean(y)) ** 2)
    R2 = 1 - SSE / SST
    adjusted_R2 = 1 - (1 - R2) * (n - 1) / (n - p - 1)
    
    return adjusted_R2

def stepwise_regression(X, y, significance_level=0.05):
    included_features = []
    adjusted_r2_values = []

    while True:
        excluded_features = list(set(X.columns) - set(included_features))
        new_adjusted_r2_values = []

        for feature in excluded_features:
            included_features.append(feature)
            adjusted_r2 = calculate_adjusted_r2(X, y, included_features)
            new_adjusted_r2_values.append((feature, adjusted_r2))
            included_features.remove(feature)

        new_adjusted_r2_values.sort(key=lambda x: x[1])
        best_feature, best_adjusted_r2 = new_adjusted_r2_values[0]

        if best_adjusted_r2 >= adjusted_r2_values[-1] if adjusted_r2_values else 0:
            included_features.append(best_feature)
            adjusted_r2_values.append(best_adjusted_r2)

            X_included = X[included_features].values

            X_transpose_X_inv = np.linalg.inv(X_included.T @ X_included)
            beta = X_transpose_X_inv @ X_included.T @ y.values.reshape(-1, 1)
            residuals = y.values.reshape(-1, 1) - X_included @ beta

            SSE = np.sum(residuals ** 2)
            MSE = SSE / (len(X) - len(included_features) - 1)
            se = np.sqrt(np.diag(MSE * X_transpose_X_inv))
            t_values = np.abs(np.mean(X_included, axis=0) / se)
            p_values = (1 - 2 * np.sum(t_values, axis=0))

            if np.min(p_values) > significance_level:
                break
        else:
            break

    results = pd.DataFrame(data={'Feature': included_features, 'Adjusted R^2': adjusted_r2_values})
    return results