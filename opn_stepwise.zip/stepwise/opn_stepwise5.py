from myutils.opn import OPN
from myutils.data_util import combine_columns
import random
import numpy as np
import pandas as pd
import time

def backward_r2stepwise_regression(X, y, threshold):
    num_features = X.shape[1]
    # included = list(range(num_features))    
    included = list(random.sample(range(num_features), num_features))    
    current_r2 = 0    
    while True:
        best_r2 = 0
        excluded_features = []
        temp_included = []        
        
        for feature in included:
            temp_features = included.copy()
            temp_features.remove(feature)            
            X_subset=X.iloc[:,temp_features]
            new1_colname='1'
            tuple_list = [(0, -1)] * len(df) 
            X_subset.insert(loc=0, column=new1_colname, value=tuple_list)
            X_subset=X_subset.to_numpy()
            y=y.to_numpy()
            XT=OPN.mat_t(X_subset)
            XTX=OPN.mat_multi(XT,X_subset)
            XTX_1=OPN.gauss_inv(XTX)
            XTY=OPN.mat_multi(XT,y)
            w=OPN.mat_multi(XTX_1,XTY)
            y_pred=pd.DataFrame(OPN.mat_multi(X_subset,w))
            
            y=pd.DataFrame(y)
            y_pred[['Column1', 'Column2']] = y_pred.iloc[:,-1].apply(lambda x: pd.Series(x))
            y_true=pd.read_csv('Concrete.csv')['strength']            
            
            ssr=np.sum((y_pred.iloc[:,1]-y_true)**2)
            sst=np.sum((y_pred.iloc[:,1]-np.mean(y_true))**2)
            r2=1-(ssr/sst)    
           
            if r2 > best_r2:
                best_r2 = r2
                print(best_r2)
                excluded_features = feature
                temp_included = temp_features 
                print(temp_included)
        
        if best_r2 - current_r2 < threshold:
            break        
        included = temp_included
        current_r2 = best_r2    
    return included

start_time=time.time()
df=pd.read_csv('Concrete.csv')
X=df.iloc[:,:-1]
data1=X.applymap(lambda x: (x, 0))
X=combine_columns(X)
X=pd.concat([X,data1],axis=1)
df['strength']=df['strength'].apply(lambda x:(x,0))
data=pd.concat([X,df['strength']],axis=1)
y=data.iloc[:,-1:]
var=backward_r2stepwise_regression(X, y, threshold=0.01)
end_time=time.time()
duration=end_time-start_time
print('time:', duration)
print('features:', var)