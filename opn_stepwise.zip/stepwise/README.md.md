# README.md

## Overview



In the realm of machine learning algorithms based on the framework of Ordered Pair of Normalized Real Numbers (OPNs), there is a sharp increase in the number of model feature variables when real-number data is converted to the corresponding OPNs form. For real-number data, the conversion results in a vast search space for the model. If these OPNs variables are entered into the machine learning model without selection, the model is prone to errors due to the large search space, and its performance will suffer dramatically. This study introduces a stepwise regression algorithm within the OPNs framework, applying binary fundamental operation units and their methods of operation from OPNs theory to stepwise regression.

## Code

### data

This folder contains the data needed for the experiment.

### myutils

opn.py encapsulates the basic operations under the OPNs framework.

data_util.py contains some functional methods for processing data.





















