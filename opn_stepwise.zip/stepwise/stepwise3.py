import numpy as np
import pandas as pd
import statsmodels.api as sm

def backward_forward_stepwise_regression(X, y):
    
    def forward_regression(X, y, initial_list=[]):
        included = list(initial_list)
        while True:
            changed = False
            excluded = [col for col in X.columns if col not in included]
            new_pval = pd.Series(index=excluded)
            for new_col in excluded:
                model = sm.OLS(y, sm.add_constant(X[included + [new_col]])).fit()
                new_pval[new_col] = model.pvalues[new_col]
            if new_pval.min() < 0.05:
                best_feature = new_pval.idxmin()
                included.append(best_feature)
                changed = True
            if not changed:
                break
        return included

    
    def backward_regression(X, y, initial_list=list(X.columns)):
        included = list(initial_list)
        while True:
            changed = False
            model = sm.OLS(y, sm.add_constant(X[included])).fit()
            pvalues = model.pvalues.iloc[1:]
            worst_feature = pvalues.idxmax()
            if pvalues.max() > 0.05:
                included.remove(worst_feature)
                changed = True
            if not changed:
                break
        return included

    forward_selected = forward_regression(X, y)
    backward_selected = backward_regression(X, y, initial_list=forward_selected)

    return backward_selected