import pandas as pd
import numpy as np
import math
import sys
import decimal




class OPN:
    '''A unique additive identity and a unique multiplicative identity'''
    zero = (0, 0)
    one = (0, -1)
    oneNeg = (0, 1)
    initialValue = [1, 0.5, 200, -101, True]
    nSlope = initialValue[0]
    ksi = initialValue[1]
    default_precision = initialValue[2]
    sign = initialValue[3]
    flag = initialValue[4]


    def __init__(self, initial_value=None):
        if initial_value is None:
            self.nSlope = 1
            self.ksi = 0.5
            self.default_precision = 200
            self.sign = -101
            self.flag = True
        else:
            self.nSlope = initial_value[0]
            self.ksi = initial_value[1]
            self.default_precision = initial_value[2]
            self.sign = initial_value[3]
            self.flag = initial_value[4]


    def add(*args):
        if len(args) == 1:
            opn_list = args[0]
        else:
            opn_list = args
        first_entry = opn_list[0][0]
        second_entry = opn_list[0][1]
        for i in range(len(opn_list) - 1):
            first_entry = OPN.add_fun(first_entry, opn_list[i + 1][0])
            second_entry = OPN.add_fun(second_entry, opn_list[i + 1][1])
        new_opn = (first_entry, second_entry)
        return new_opn

    
    def multi(*args):
        if len(args) == 1:
            opn_list = args[0]
        else:
            opn_list = args
        first_entry, second_entry = opn_list[0][0], opn_list[0][1]
        for i in range(len(opn_list) - 1):
            temp = first_entry
            first_entry = OPN.add_fun(OPN.multi_fun(first_entry, -opn_list[i + 1][1]),
                                      OPN.multi_fun(second_entry, -opn_list[i + 1][0]))
            second_entry = OPN.add_fun(OPN.multi_fun(temp, -opn_list[i + 1][0]),
                                       OPN.multi_fun(second_entry, -opn_list[i + 1][1]))
        new_opn = (first_entry, second_entry)
        return new_opn

    
    def add_fun(interval_number1, interval_number2):
        return interval_number1 + interval_number2

    
    def multi_fun(interval_number1, interval_number2):
        return interval_number1 * interval_number2

    
    def scalar_multi(real_number, opn=()):
        head = OPN.scalar_multi_fun(real_number, opn[0])
        tail = OPN.scalar_multi_fun(real_number, opn[1])
        new_opn = (head, tail)
        return new_opn

    
    def scalar_multi_fun(real_number, interval_number):
        return real_number * interval_number

    
    def div(opn1=(), opn2=()):
        new_opn = OPN.multi(opn1, OPN.neg_power(opn2))
        return new_opn

    
    def sub(opn1=(), opn2=()):
        new_opn = OPN.add(opn1, OPN.scalar_multi(-1, opn2))
        return new_opn

    
    def neg_power(opn=()):
        if opn[0] == opn[1] or opn[0] == -opn[1]:
            sys.exit('The multiplication inverse of this OPN {} does not exist'.format(opn))
        else:
            first_entry = opn[0] / (opn[0] ** 2 - opn[1] ** 2)
            second_entry = opn[1] / (opn[1] ** 2 - opn[0] ** 2)
            new_opn = (first_entry, second_entry)
            return new_opn

    
    def mat_t(matrix):
        trans_mat = [[0 for x in range(len(matrix))] for x in range(len(matrix[0]))]
        for i in range(len(matrix)):
            for j in range(len(matrix[0])):
                trans_mat[j][i] = matrix[i][j]
        return trans_mat

    
    def mat_multi(mat_1, mat_2):
        try:
            if type(mat_1) == tuple and len(mat_1) == 2:
                multi_mat = [[OPN.zero for x in range(len(mat_2[0]))] for x in range(len(mat_2))]
                for i in range(len(multi_mat)):
                    for j in range(len(multi_mat[0])):
                        multi_mat[i][j] = OPN.multi(mat_1, mat_2[i][j])
                return multi_mat
            elif len(mat_1[0]) != len(mat_2):
                sys.exit('mismatch between the number of columns in matrix 1 and the size of rows in matrix 2')
            else:
                multi_mat = [[OPN.zero for x in range(len(mat_2[0]))] for x in range(len(mat_1))]
                for i in range(len(multi_mat)):
                    for j in range(len(multi_mat[0])):
                        element = OPN.zero
                        for x in range(len(mat_2)):
                            element = OPN.add(element, OPN.multi(mat_1[i][x], mat_2[x][j]))
                        multi_mat[i][j] = element
                return multi_mat
        except Exception as e:
            sys.exit(e)

    
    def gauss_inv(matrix):
        identity_mat = [[OPN.zero for j in range(len(matrix))] for i in range(len(matrix))]
        for i in range(len(matrix)):
            identity_mat[i][i] = OPN.one
        merge_matrix = [a1 + a2 for a1, a2 in zip(matrix, identity_mat)]
        for i in range(len(merge_matrix)):
            ele = merge_matrix[i][i]
            for k in range(len(merge_matrix[i])):
                merge_matrix[i][k] = OPN.div(merge_matrix[i][k], ele)
            for j in range(len(merge_matrix)):
                if j != i:
                    ele = merge_matrix[j][i]
                    for k in range(len(merge_matrix[j])):
                        merge_matrix[j][k] = OPN.sub(merge_matrix[j][k], OPN.multi(ele, merge_matrix[i][k]))
        inv_mat = [row[len(matrix):] for row in merge_matrix]
        return inv_mat

    
    def mat_pop(mat_1, mat_2, operator='+'):
        try:
            if len(mat_1) != len(mat_2) or len(mat_1[0]) != len(mat_2[0]):
                sys.exit('The shapes of the two matrices do not match!')
            algorithm_dict = {'+': OPN.add, '-': OPN.sub, '*': OPN.multi, '/': OPN.div}
            algorithm = algorithm_dict[operator]
            new_mat = [[OPN.zero for x in range(len(mat_1[0]))] for x in range(len(mat_1))]
            for i in range(len(mat_1)):
                for j in range(len(mat_1[0])):
                    new_mat[i][j] = algorithm(mat_1[i][j], mat_2[i][j])
            return new_mat
        except Exception as e:
            sys.exit(e)

    def power(opn=(), n=2, out_accuracy=default_precision):
        if n % 1 != 0:
            sys.exit('不规范的次方\'{}\': 该运算规则power()仅支持整数次方!'.format(n))
        if n == 1:
            return opn
        elif n < 0 and (opn[0] == -opn[1] or opn[0] == opn[1]):
            sys.exit('The multiplication inverse of this OPN {} does not exist'.format(opn))
        else:
            head = (((-1) ** (n + 1)) / 2) * ((opn[0] + opn[1]) ** n)
            tail = 0.5 * ((opn[0] - opn[1]) ** n)
            first_entry = head + tail
            second_entry = head - tail
            new_opn = (first_entry, second_entry)
            return new_opn
    def square(opn=(), out_accuracy=default_precision):
        head = -2 * opn[0] * opn[1]
        tail = -opn[0] ** 2 - opn[1] ** 2
        # tail = -(opn[0] ** 2 + opn[1] ** 2)
        new_opn = (head, tail)
        return new_opn