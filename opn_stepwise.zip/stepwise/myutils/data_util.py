import pandas as pd
import numpy as np
import ast

def combine_columns(df):
    new_df = pd.DataFrame()
    columns = df.columns.tolist()
    for i in range(len(columns) - 1):
        for j in range(i + 1, len(columns)):
            col_name = f"{columns[i]}_{columns[j]}"
            new_df[col_name] = list(zip(df[columns[i]], df[columns[j]]))
    return new_df


def convert_to_tuple(value):  
    return ast.literal_eval(value)

def calculate_residuals(X, y, variables):
    # X_subset = np.hstack((np.ones((X.shape[0], 1)), X[:, variables]))
    if len(variables) == 1:
        X_subset = list(X[:,variables[0]])
        X_subset = np.hstack((np.ones((len(X_subset), 1)), X_subset))
    else:
        X1 = list(X[:,variables])
        X_subset = [[elem for tpl in arr for elem in tpl] for arr in X1]  
        X_subset = np.hstack((np.ones((len(X_subset), 1)), X_subset))
    coefficients = np.linalg.lstsq(X_subset, y, rcond=None)[0]
    y_pred = np.dot(X_subset, coefficients)
    # print(y_pred)
    residuals = y - y_pred
    return residuals

def calculate_f_statistic(residuals, included, excluded, X, y):
    sse_included = np.sum(residuals**2)
    df_included = len(included)
    mse_included = sse_included / (X.shape[0] - df_included - 1)
    sse_excluded = np.sum((y - np.mean(y))**2) - sse_included
    df_excluded = len(excluded)
    mse_excluded = sse_excluded / (X.shape[0] - df_excluded - 1)
    f_statistic = ((sse_excluded - sse_included) / (df_excluded - df_included)) / mse_included
    return f_statistic

def f_test_critical_value(alpha, dfn, dfd):
    q = np.arange(0.001, 0.999, 0.001)
    quantiles = np.quantile(np.random.f(dfn, dfd, 100000), q)
    return np.interp(1 - alpha, 1 - q, quantiles)