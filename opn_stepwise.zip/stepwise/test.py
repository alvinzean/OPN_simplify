from myutils.opn import OPN

print(OPN.add((1,1),(1,2)))
